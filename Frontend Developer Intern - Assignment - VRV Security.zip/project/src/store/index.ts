import { create } from 'zustand';
import { Role, User, Permission } from '../types';

interface RBACStore {
  users: User[];
  roles: Role[];
  addUser: (user: User) => void;
  updateUser: (id: string, user: Partial<User>) => void;
  deleteUser: (id: string) => void;
  addRole: (role: Role) => void;
  updateRole: (id: string, role: Partial<Role>) => void;
  deleteRole: (id: string) => void;
}

// Mock initial data
const mockRoles: Role[] = [
  {
    id: '1',
    name: 'Admin',
    description: 'Full system access',
    permissions: ['read', 'write', 'delete', 'manage_users', 'manage_roles'],
    createdAt: new Date().toISOString(),
  },
  {
    id: '2',
    name: 'Editor',
    description: 'Can edit content',
    permissions: ['read', 'write'],
    createdAt: new Date().toISOString(),
  },
];

const mockUsers: User[] = [
  {
    id: '1',
    name: 'Siddhesh Patil',
    email: 'siddheshpatil@vrvsecurity.com',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop',
    roleId: '1',
    status: 'active',
    lastActive: new Date().toISOString(),
  },
  {
    id: '2',
    name: 'Deepak Palwe',
    email: 'palwedeepak@vrvsecurity.com',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&fit=crop',
    roleId: '2',
    status: 'active',
    lastActive: new Date().toISOString(),
  },
];

export const useStore = create<RBACStore>((set) => ({
  users: mockUsers,
  roles: mockRoles,
  addUser: (user) => set((state) => ({ users: [...state.users, user] })),
  updateUser: (id, updatedUser) =>
    set((state) => ({
      users: state.users.map((user) =>
        user.id === id ? { ...user, ...updatedUser } : user
      ),
    })),
  deleteUser: (id) =>
    set((state) => ({
      users: state.users.filter((user) => user.id !== id),
    })),
  addRole: (role) => set((state) => ({ roles: [...state.roles, role] })),
  updateRole: (id, updatedRole) =>
    set((state) => ({
      roles: state.roles.map((role) =>
        role.id === id ? { ...role, ...updatedRole } : role
      ),
    })),
  deleteRole: (id) =>
    set((state) => ({
      roles: state.roles.filter((role) => role.id !== id),
    })),
}));