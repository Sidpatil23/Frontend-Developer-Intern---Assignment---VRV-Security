import React, { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { UserList } from './components/UserList';
import { RoleList } from './components/RoleList';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');

  return (
    <div className="min-h-screen bg-gray-100">
      <Sidebar activeTab={activeTab} onTabChange={setActiveTab} />
      
      <div className="pl-64">
        <header className="bg-white shadow">
          <div className="px-8 py-6">
            <h1 className="text-2xl font-semibold text-gray-900">
              {activeTab.charAt(0).toUpperCase() + activeTab.slice(1)}
            </h1>
          </div>
        </header>
        
        <main className="p-8">
          {activeTab === 'dashboard' && <Dashboard />}
          {activeTab === 'users' && <UserList />}
          {activeTab === 'roles' && <RoleList />}
        </main>
      </div>
    </div>
  );
}

export default App;