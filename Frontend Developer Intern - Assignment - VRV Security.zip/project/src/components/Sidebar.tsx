import React from 'react';
import { Users, Shield, Home } from 'lucide-react';
import { useStore } from '../store';

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export function Sidebar({ activeTab, onTabChange }: SidebarProps) {
  const users = useStore((state) => state.users);
  const roles = useStore((state) => state.roles);

  return (
    <div className="w-64 bg-gray-900 text-white h-screen fixed left-0 top-0">
      <div className="p-6">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Shield className="w-8 h-8" />
          VRV Security
        </h1>
      </div>
      
      <nav className="mt-6">
        <button
          onClick={() => onTabChange('dashboard')}
          className={`w-full flex items-center gap-3 px-6 py-3 text-sm font-medium ${
            activeTab === 'dashboard'
              ? 'bg-gray-800 text-white'
              : 'text-gray-400 hover:bg-gray-800 hover:text-white'
          }`}
        >
          <Home className="w-5 h-5" />
          Dashboard
        </button>
        
        <button
          onClick={() => onTabChange('users')}
          className={`w-full flex items-center gap-3 px-6 py-3 text-sm font-medium ${
            activeTab === 'users'
              ? 'bg-gray-800 text-white'
              : 'text-gray-400 hover:bg-gray-800 hover:text-white'
          }`}
        >
          <Users className="w-5 h-5" />
          Users ({users.length})
        </button>
        
        <button
          onClick={() => onTabChange('roles')}
          className={`w-full flex items-center gap-3 px-6 py-3 text-sm font-medium ${
            activeTab === 'roles'
              ? 'bg-gray-800 text-white'
              : 'text-gray-400 hover:bg-gray-800 hover:text-white'
          }`}
        >
          <Shield className="w-5 h-5" />
          Roles ({roles.length})
        </button>
      </nav>
    </div>
  );
}